select * from [Lms.Core].[Tenants] where name like '%hpegsr';

SELECT *
FROM (
    SELECT 
        CASE
            WHEN Surname IS NOT NULL THEN Surname
            ELSE '.'
        END AS LASTNAME ,
        *
    FROM [Lms.Core].[Users] 
) AS Subquery
WHERE Tenantid =586; 


select * from [Lms.Core].[Tenants] where id=586;

select * from [Lms.Core].[TenantCatalogs] where tenantid=586;

select * from [Lms.Core].[CatalogItems] where CatalogDefinitionId in(825,
849) and Scope=50;

WITH RankedRows AS (
  SELECT
    f.*,
    ROW_NUMBER() OVER (PARTITION BY a.Id ORDER BY a.Id) AS RowNum
	from [Lms.Core].[CatalogItems] d (nolock)
inner join [Lms.Core].[ResourceSkillProficiencyMappings] c (nolock)
on d.ScopeId=c.ResourceId and c.ResourceType=1 and d.Scope=50
inner join [Lms.Core].[ResourceCategories] b (nolock)
on b.ResourceId=d.ScopeId and b.ResourceType=1 and d.Scope=50
inner join [Lms.Core].[Categories] a (nolock)
on a.Id=b.CategoryId
inner join [Lms.Core].[Images] f (nolock)
on f.ScopeId=a.id and f.Scope=40
where d.CatalogDefinitionId in(825,849) and c.TenantId is null and f.thumbnailURL is not null)
SELECT
  *
FROM
  RankedRows
WHERE
  RowNum = 1;


  --categories
WITH RankedRows AS (
  SELECT
    a.*,
    ROW_NUMBER() OVER (PARTITION BY a.Id ORDER BY a.Id) AS RowNum
	from [Lms.Core].[CatalogItems] d (nolock)
inner join [Lms.Core].[ResourceSkillProficiencyMappings] c (nolock)
on d.ScopeId=c.ResourceId and c.ResourceType=1 and d.Scope=50
inner join [Lms.Core].[ResourceCategories] b (nolock)
on b.ResourceId=d.ScopeId and b.ResourceType=1 and d.Scope=50
inner join [Lms.Core].[Categories] a (nolock)
on a.Id=b.CategoryId
inner join [Lms.Core].[Images] f (nolock)
on f.ScopeId=a.id and f.Scope=40
where d.CatalogDefinitionId in(825,849) and c.TenantId is null)
SELECT
  *
FROM
  RankedRows
WHERE
  RowNum = 1;