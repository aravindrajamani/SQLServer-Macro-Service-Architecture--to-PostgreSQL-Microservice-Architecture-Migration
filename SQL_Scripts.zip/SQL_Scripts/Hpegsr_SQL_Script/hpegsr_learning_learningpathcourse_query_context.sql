--LearningPathid
     select cd.Id as CatalogId,cd.CatalogName,c.Id as LpId,c.IdNumber as LpIdNumber ,c.LearningPathName
from [Lms.Core].[CatalogDefintions](nolock) cd    
join [Lms.Core].[CatalogItems](nolock) ci on ci.CatalogDefinitionId=cd.Id   
join [Lms.Core].[LearningPaths](nolock) c on c.Id=ci.ScopeId   
where ci.scope =100 and c.IsDeleted=0 and ci.IsDeleted=0 and CatalogDefinitionId in (825,849);


--LearningPath
SELECT Lp.id as LearningPathId, Lp.LearningPathName, c.id as CourseID, c.idNumber, c.fullname 
FROM  [Lms.Core].[Courses](NOLOCK) c  
  Join [Lms.Core].[LearningPathCourses] lpc ON lpc.[CourseId]= c.ID and lpc.isdeleted=0 
JOIN [Lms.Core].[LearningPaths](NOLOCK) lp ON lp.Id = lpc.[LearningPathId] and lp.IsDeleted <> 1  
where  c.IsDeleted <> 1 and lp.id in (8729)	
order by LearningPathId desc;