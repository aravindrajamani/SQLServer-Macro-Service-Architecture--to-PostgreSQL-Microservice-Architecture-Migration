  select cd.Id as CatalogId,cd.CatalogName,c.Id as CourseId,c.IdNumber as CourseIdNumber ,c.FullName as CourseFullName 
from [Lms.Core].[CatalogDefintions](nolock) cd  
join [Lms.Core].[CatalogItems](nolock) ci on ci.CatalogDefinitionId=cd.Id 
join [Lms.Core].[Courses](nolock) c on c.Id=ci.ScopeId 
where ci.scope =50 and c.IsDeleted=0 and ci.IsDeleted=0 and cd.IsDeleted=0 and cd.id in (825,849);







WITH RankedRows AS (
  SELECT
    e.*,
    ROW_NUMBER() OVER (PARTITION BY e.Id ORDER BY e.Id) AS RowNum
	from [Lms.Core].[CatalogDefintions] a (nolock)
	inner join [Lms.Core].[CatalogItems] d (nolock)
	on a.Id=d.CatalogDefinitionId
    inner join [Lms.Core].[Courses] e (nolock)
    on d.ScopeId=e.Id
	inner join [Lms.Core].[ResourceCategories] c (nolock)
	on c.ResourceId=e.id and c.IsDeleted <> 1 and c.ResourceType=1
	inner join [Lms.Core].[Categories] g (nolock)
	on g.Id=c.CategoryId
inner join [Lms.Core].[Images] f (nolock)
on f.ScopeId=e.id and f.Scope=10
where d.Scope=50 and e.isdeleted=0 and a.IsDeleted=0 and d.IsDeleted=0 and d.CatalogDefinitionId in(825,849) and e.id in(1164887	,
1165095	,
1200950	,
1161885	,
1148384	,
1201508	,
1117007	,
1116999	,
1116964	,
1116988	,
1116969	,
1117004	,
1116981	,
1117001	,
1117000	,
1117002	,
1116979	,
1116991	,
1116960	,
1117206	,
1117204	,
1117205	,
1116976	,
1116986	,
1116959	,
1116998	,
1158641	,
1133704	,
1133446	,
1133481	,
1133483	,
1133409	,
1147579	,
1116974	,
1117349	,
1148378	,
1117564	,
1119100	,
1117201	,
1117202	,
1116970	,
1116956	,
1148036	,
1158565	,
1159222	,
1117210	,
1117012	,
1116990	,
1116977	,
1116987	,
1116975	,
1116966	,
1116973	,
1116982	,
1116955	,
1116951	,
1116997	,
1116992	,
1116952	,
1117211	,
1116972	,
1116968	,
1117003	,
1116965	,
1116950	,
1117209	,
1117208	,
1117203	,
1116962	,
1116980	,
1116957	,
1116996	,
1116958	,
1116971	,
1117006	,
1116967	,
1116978	,
1117005	,
1116963	,
1116961	,
1116953	,
1147575	,
1147590	,
1147576	,
1147810	,
1147607	,
1148069	,
1147591	,
1147844	,
1147823	,
1147617	,
1206548	,
1206547	,
1206545	,
1206544	,
1206546	,
1206549	,
1206550	,
1206613	,
1206783	,
1206784	,
1207487	,
1206691	,
1206756	,
1206757	,
1206760	,
1206763	
)
)SELECT
  *
FROM
  RankedRows
WHERE
  RowNum = 1;