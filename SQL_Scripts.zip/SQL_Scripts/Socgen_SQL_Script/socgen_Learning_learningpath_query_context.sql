WITH RankedRows AS (
  SELECT
    c.*,
    ROW_NUMBER() OVER (PARTITION BY c.Id ORDER BY c.Id) AS RowNum
	from [Lms.Core].[CatalogDefintions](nolock) cd  
join [Lms.Core].[CatalogItems](nolock) ci on ci.CatalogDefinitionId=cd.Id 
join [Lms.Core].[LearningPaths](nolock) c on c.Id=ci.ScopeId 
join  [Lms.Core].[ResourceCategories] rc on rc.ResourceId=c.Id and rc.IsDeleted<>1 and rc.ResourceType=2  
JOIN [Lms.Core].[Categories] cat on cat.Id=rc.CategoryId  
left join [Lms.Core].[Images] f (nolock)
on f.ScopeId=c.id and f.Scope=20
where ci.scope =100 and c.IsDeleted=0 and ci.IsDeleted=0 and cd.IsDeleted=0 and cd.id in (72,74,88,89,100,101,182,366)
)
SELECT
  *
FROM
  RankedRows
WHERE
  RowNum = 1;