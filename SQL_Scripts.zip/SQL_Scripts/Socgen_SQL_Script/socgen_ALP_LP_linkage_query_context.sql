--CertificationPathid
     select cd.Id as CatalogId,cd.CatalogName,c.Id as cpId,c.IdNumber as cpIdNumber ,c.CertificationPathName
from [Lms.Core].[CatalogDefintions](nolock) cd    
join [Lms.Core].[CatalogItems](nolock) ci on ci.CatalogDefinitionId=cd.Id   
join [Lms.Core].[CertificationPaths](nolock) c on c.Id=ci.ScopeId   
where ci.scope =150 and c.IsDeleted=0 and ci.IsDeleted=0 and CatalogDefinitionId in (72,74,88,89,100,101,182,366); 
  
  
  
 
  
  --advanced_learning_path_linkage_with_LP
  
  
  Select  cp.id as certificatePathID, cp.CertificationPathName, lp.id, lp.LearningPathName 
  from  [Lms.Core].[CertificationPaths] cp 
  join [Lms.Core].[CertificationPathLearningPaths] (NOLOCK)cl on cp.id=cl.CertificationPathId 
  join [Lms.Core].[LearningPaths](NOLOCK) lp on lp.id=cl.LearningPathId 
  where cp. id in (237,
297,
298,
299,
300,
325,
326)  
  and cp.IsDeleted=0 and cl.IsDeleted=0 and lp.IsDeleted=0;