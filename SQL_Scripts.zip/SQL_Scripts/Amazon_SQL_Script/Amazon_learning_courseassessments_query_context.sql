  --assessments
WITH RankedRows AS (
  SELECT
    a.*,
    ROW_NUMBER() OVER (PARTITION BY a.Id ORDER BY a.Id) AS RowNum,
    c.CourseId,
	d.FullName,
    z.testName_moduleURL,
    z.testName_configsettings,
	y.UserId,
	y.ProgressJson,
	y.LastAccessedTime,
	y.StartDateTime,
	a.Id as yashsha_module_ID
  FROM
    [Lms.Core].[ModuleInstances] a (NOLOCK)
    INNER JOIN [Lms.Core].[ModuleProviderDefinitions] g (NOLOCK) ON a.ModuleProviderDefinitionId = g.Id
    INNER JOIN [Lms.Core].[SectionModuleInstances] b (NOLOCK) ON a.id = b.ModuleInstanceId
	Inner join [Lms.Core].[UserModuleInstanceProgresses] y (NOLOCK) on y.SectionModuleInstanceId=b.Id
    INNER JOIN [Lms.Core].[CourseSections] c (NOLOCK) ON b.SectionId = c.SectionInstanceId
    INNER JOIN [Lms.Core].[Courses] d (NOLOCK) ON c.CourseId = d.Id
    INNER JOIN [Lms.Core].[CatalogItems] e (NOLOCK) ON d.id = e.scopeId
    INNER JOIN [Lms.Core].[CatalogDefintions] f (NOLOCK) ON e.CatalogDefinitionId = f.Id
    CROSS APPLY (
      SELECT 
        TRY_CAST(a.ModuleURL AS NVARCHAR(MAX)) AS ModuleURL,
        TRY_CAST(a.ConfigSettings AS NVARCHAR(MAX)) AS ConfigSettings
    ) AS JSONData
    CROSS APPLY OPENJSON(JSONData.ModuleURL)
    WITH (
       testName_moduleURL NVARCHAR(MAX) '$.testName',
       testName_configsettings NVARCHAR(MAX) '$.testName'
    ) z
  WHERE
    LOWER(y.ProgressJson) NOT LIKE '{"AssessmentUrl":"https://ide%' and LOWER(y.ProgressJson) NOT LIKE '{"AssessmentUrl":"http://ide%' and e.CatalogDefinitionId IN (358,363,698,699) AND e.Scope = 50 AND a.ModuleProviderDefinitionId IN (4) and ISJSON(a.ModuleURL) = 1 and ISJSON(a.ConfigSettings) =1 
)
SELECT
  *
FROM
  RankedRows
WHERE
  RowNum = 1;

  --119387,132138,132521,190436,132808,833972,132779,191121,833495,840810,898782