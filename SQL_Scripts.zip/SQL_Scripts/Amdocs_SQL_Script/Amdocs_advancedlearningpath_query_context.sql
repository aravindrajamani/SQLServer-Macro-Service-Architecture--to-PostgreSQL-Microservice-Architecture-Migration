WITH RankedRows AS (
  SELECT
    c.*,
    ROW_NUMBER() OVER (PARTITION BY c.Id ORDER BY c.Id) AS RowNum,f.id as 'imageid'
from [Lms.Core].[CatalogDefintions](nolock) cd  
join [Lms.Core].[CatalogItems](nolock) ci on ci.CatalogDefinitionId=cd.Id 
join [Lms.Core].[CertificationPaths](nolock) c on c.Id=ci.ScopeId 
join  [Lms.Core].[ResourceCategories] rc on rc.ResourceId=c.Id and rc.IsDeleted<>1 and rc.ResourceType=4  
JOIN [Lms.Core].[Categories] cat on cat.Id=rc.CategoryId  
left join [Lms.Core].[Images] f (nolock)
on f.ScopeId=c.id and f.Scope=60
where ci.scope =150 and c.IsDeleted=0 and ci.IsDeleted=0 and cd.IsDeleted=0 and cd.id in (8,148,8,145,148,448,449,453,454,461,462,463,464)
)
SELECT
  *
FROM
  RankedRows
WHERE
  RowNum = 1;