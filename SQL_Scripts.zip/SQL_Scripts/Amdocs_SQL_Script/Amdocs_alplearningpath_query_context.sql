--CertificationPathid
     select cd.Id as CatalogId,cd.CatalogName,c.Id as cpId,c.IdNumber as cpIdNumber ,c.CertificationPathName
from [Lms.Core].[CatalogDefintions](nolock) cd    
join [Lms.Core].[CatalogItems](nolock) ci on ci.CatalogDefinitionId=cd.Id   
join [Lms.Core].[CertificationPaths](nolock) c on c.Id=ci.ScopeId   
where ci.scope =150 and c.IsDeleted=0 and ci.IsDeleted=0 and CatalogDefinitionId in (8,148,8,145,148,448,449,453,454,461,462,463,464); 
  
  
  
 
  
  --advanced_learning_path_linkage_with_LP
  
  
  Select  cp.id as certificatePathID, cp.CertificationPathName, lp.id, lp.LearningPathName 
  from  [Lms.Core].[CertificationPaths] cp 
  join [Lms.Core].[CertificationPathLearningPaths] (NOLOCK)cl on cp.id=cl.CertificationPathId 
  join [Lms.Core].[LearningPaths](NOLOCK) lp on lp.id=cl.LearningPathId 
  where cp. id in (76,77,78,157,215,228)  
  and cp.IsDeleted=0 and cl.IsDeleted=0 and lp.IsDeleted=0;