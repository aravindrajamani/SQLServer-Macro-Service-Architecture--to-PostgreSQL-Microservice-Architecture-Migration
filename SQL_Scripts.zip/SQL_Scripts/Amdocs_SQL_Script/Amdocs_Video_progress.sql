WITH CTE AS (
    SELECT 
        b.*, 
        c.moduleinstanceId,
        ROW_NUMBER() OVER (ORDER BY a.id) AS RowNum
    FROM [Lms.Core].[Users] a (NOLOCK)
    INNER JOIN [Lms.Core].[UserModuleInstanceProgresses] b (NOLOCK) ON a.id = b.UserId
    INNER JOIN [Lms.Core].[SectionModuleInstances] c (NOLOCK) ON b.SectionModuleInstanceId = c.id
    WHERE a.TenantId = 15
)
SELECT *
FROM CTE
WHERE RowNum BETWEEN 1 AND 1000000;




WITH CTE AS (
    SELECT 
        b.*, 
        c.moduleinstanceId,
        ROW_NUMBER() OVER (ORDER BY a.id) AS RowNum
    FROM [Lms.Core].[Users] a (NOLOCK)
    INNER JOIN [Lms.Core].[UserModuleInstanceProgresses] b (NOLOCK) ON a.id = b.UserId
    INNER JOIN [Lms.Core].[SectionModuleInstances] c (NOLOCK) ON b.SectionModuleInstanceId = c.id
    WHERE a.TenantId = 15
)
SELECT *
FROM CTE
WHERE RowNum BETWEEN 1000001 AND 2000000;

WITH CTE AS (
    SELECT 
        b.*, 
        c.moduleinstanceId,
        ROW_NUMBER() OVER (ORDER BY a.id) AS RowNum
    FROM [Lms.Core].[Users] a (NOLOCK)
    INNER JOIN [Lms.Core].[UserModuleInstanceProgresses] b (NOLOCK) ON a.id = b.UserId
    INNER JOIN [Lms.Core].[SectionModuleInstances] c (NOLOCK) ON b.SectionModuleInstanceId = c.id
    WHERE a.TenantId = 15
)
SELECT *
FROM CTE
WHERE RowNum BETWEEN 2000001 AND 2056985;

