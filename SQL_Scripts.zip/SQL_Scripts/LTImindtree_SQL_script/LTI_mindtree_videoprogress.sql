select b.*,c.moduleinstanceId
from [Lms.Core].[Users] a (nolock)
inner join [Lms.Core].[UserModuleInstanceProgresses] b (nolock)
on a.id=b.UserId
inner join [Lms.Core].[SectionModuleInstances] c (nolock)
on b.SectionModuleInstanceId=c.id
where a.TenantId=446;