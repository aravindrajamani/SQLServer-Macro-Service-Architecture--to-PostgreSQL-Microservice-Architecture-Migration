  Select  cp.id as certificatePathID, cp.CertificationPathName, lp.id, lp.LearningPathName 
  from  [Lms.Core].[CertificationPaths] cp 
  join [Lms.Core].[CertificationPathLearningPaths] (NOLOCK)cl on cp.id=cl.CertificationPathId 
  join [Lms.Core].[LearningPaths](NOLOCK) lp on lp.id=cl.LearningPathId 
  where cp. id in (232,
362)  
  and cp.IsDeleted=0 and cl.IsDeleted=0 and lp.IsDeleted=0;